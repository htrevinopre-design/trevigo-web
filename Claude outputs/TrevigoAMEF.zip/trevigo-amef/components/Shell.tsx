import Link from "next/link";
import type { Session } from "@/lib/auth";
import { PIE_GOBERNANZA } from "@/lib/amef";

export default function Shell({
  session,
  linea,
  children,
}: {
  session: Session;
  linea?: { nombre: string; topologia: string; plantaNombre: string; esDemo: boolean };
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-petrol-950 text-white">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="font-black text-lg tracking-tight">
              SurfaceOS <span className="text-petrol-100 font-semibold">· AMEF vivo</span>
            </Link>
            <nav className="flex gap-4 text-sm">
              <Link href="/" className="text-petrol-100 hover:text-white">Bandeja</Link>
              <Link href="/amef" className="text-petrol-100 hover:text-white">AMEF vivo</Link>
              <Link href="/captura" className="text-petrol-100 hover:text-white">Captura</Link>
            </nav>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <span className="text-petrol-100 hidden sm:inline">{session.name}</span>
            <form action="/api/auth/logout" method="post">
              <button className="text-petrol-100 hover:text-white border border-petrol-700 rounded px-3 py-1">
                Salir
              </button>
            </form>
          </div>
        </div>
        {linea && (
          <div className="bg-petrol-900 border-t border-petrol-800">
            <div className="max-w-6xl mx-auto px-4 py-1.5 flex items-center gap-2 text-xs text-petrol-100">
              <span className="font-bold">{linea.plantaNombre}</span>
              <span>·</span>
              <span>{linea.nombre}</span>
              <span>·</span>
              <span>{linea.topologia}</span>
              {linea.esDemo && (
                <span className="ml-2 bg-amber-400 text-amber-950 font-black uppercase text-[10px] tracking-wider rounded px-2 py-0.5">
                  Planta de demostración · datos simulados
                </span>
              )}
            </div>
          </div>
        )}
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 w-full flex-1">{children}</main>

      <footer className="border-t border-slate-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <p className="text-[11px] leading-relaxed text-slate-500">{PIE_GOBERNANZA}</p>
        </div>
      </footer>
    </div>
  );
}
