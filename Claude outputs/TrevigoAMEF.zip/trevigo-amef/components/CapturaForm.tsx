"use client";

import { useEffect, useRef, useState } from "react";

type Param = {
  id: string;
  etapaNum: number;
  etapaNombre: string;
  nombre: string;
  unidad: string;
  specText: string;
  anterior: number | null;
};

export default function CapturaForm({
  params,
  action,
}: {
  params: Param[];
  action: (formData: FormData) => Promise<void>;
}) {
  const [seg, setSeg] = useState(0);
  const inicioRef = useRef(Date.now());
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    const t = setInterval(() => setSeg(Math.floor((Date.now() - inicioRef.current) / 1000)), 1000);
    return () => clearInterval(t);
  }, []);

  function igualQueAyer(id: string, valor: number | null) {
    if (valor === null || !formRef.current) return;
    const input = formRef.current.querySelector<HTMLInputElement>(`input[name="p_${id}"]`);
    if (input) input.value = String(valor);
  }

  function todosIgual() {
    for (const p of params) igualQueAyer(p.id, p.anterior);
  }

  const mm = String(Math.floor(seg / 60)).padStart(1, "0");
  const ss = String(seg % 60).padStart(2, "0");

  return (
    <form
      ref={formRef}
      action={(fd) => {
        fd.set("duracionSeg", String(Math.floor((Date.now() - inicioRef.current) / 1000)));
        return action(fd);
      }}
      className="space-y-4"
    >
      <div className="sticky top-0 z-10 bg-petrol-950 text-white rounded-xl px-4 py-2.5 flex items-center justify-between">
        <span className="text-sm font-bold">
          Cronómetro <span className="font-mono text-lg ml-2">{mm}:{ss}</span>
          <span className={`ml-2 text-xs ${seg <= 60 ? "text-emerald-300" : "text-amber-300"}`}>
            {seg <= 60 ? "vas ganándole al papel" : "el papel toma 60–90 s"}
          </span>
        </span>
        <button
          type="button"
          onClick={todosIgual}
          className="text-xs font-bold border border-petrol-700 hover:bg-petrol-800 rounded px-3 py-1.5"
        >
          Todos igual que ayer
        </button>
      </div>

      <input type="hidden" name="duracionSeg" value="" />

      {params.map((p, i) => {
        const nuevaEtapa = i === 0 || params[i - 1].etapaNum !== p.etapaNum;
        return (
          <div key={p.id}>
            {nuevaEtapa && (
              <p className="text-[11px] uppercase tracking-wider font-black text-petrol-700 mt-4 mb-2">
                Etapa {p.etapaNum} · {p.etapaNombre}
              </p>
            )}
            <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-wrap items-center gap-3">
              <div className="flex-1 min-w-[160px]">
                <p className="font-semibold text-sm text-slate-800">{p.nombre}</p>
                <p className="text-[11px] text-slate-400">
                  {p.unidad} · spec {p.specText}
                  {p.anterior !== null && <> · ayer: <span className="font-mono">{p.anterior}</span></>}
                </p>
              </div>
              <input
                name={`p_${p.id}`}
                type="number"
                step="any"
                inputMode="decimal"
                className="border border-slate-300 rounded-lg px-3 py-2 w-28 text-right font-mono"
              />
              {p.anterior !== null && (
                <button
                  type="button"
                  onClick={() => igualQueAyer(p.id, p.anterior)}
                  className="text-xs font-bold text-petrol-600 border border-petrol-100 bg-petrol-50 hover:bg-petrol-100 rounded px-3 py-2"
                >
                  Igual que ayer
                </button>
              )}
            </div>
          </div>
        );
      })}

      <button className="w-full bg-petrol-600 hover:bg-petrol-700 text-white font-black py-3 rounded-xl">
        Registrar chequeo
      </button>
    </form>
  );
}
