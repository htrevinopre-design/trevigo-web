# SurfaceOS · AMEF vivo

AMEF de proceso (AIAG-VDA) sustentado en la bitácora digital de la línea. El sistema cuenta eventos de causa
(lecturas fuera de rango sobre turnos registrados), propone revisiones de ocurrencia con evidencia, y una
persona las aprueba y firma. Append-only. Incluye planta de demostración con la línea genérica de fosfato
de zinc — sin datos de clientes reales.

## Puesta en marcha

1. **Base de datos**: en el proyecto de Neon existente, crear una database nueva llamada `amef`
   (Neon → proyecto → Databases → New Database). El `DATABASE_URL` es el mismo del CRM cambiando
   `/neondb` por `/amef` al final.
2. `.env` con `DATABASE_URL`, `AUTH_SECRET` (aleatorio), `SEED_PASSWORD`.
3. `npm install && npm run db:push && npm run db:seed`
4. GitHub: repo privado `trevigo-amef` → push.
5. Vercel: importar, framework Next.js, variables `DATABASE_URL` y `AUTH_SECRET`, deploy.
6. Dominio: `amef.trevigo.com.mx` → CNAME en el Zone Editor de Neubox (Vercel indica el valor).

Usuarios seed: hernan.trevino@ / blanca@ / norma@trevigo.com.mx · contraseña = SEED_PASSWORD.

## Reglas que este código respeta (del documento de traspaso)

- El sistema **nunca** modifica el AMEF solo: propone, y la revisión se aprueba y firma con nombre y fecha.
- El rechazo también queda firmado ("se conserva la ocurrencia vigente") — cláusula 6.1.
- Ocurrencia en la **causa** (AIAG-VDA), contada como lecturas fuera de rango / turnos registrados.
- Playbook siempre con numerador y denominador; las acciones que fallaron se muestran igual.
- Severidad jamás se propone automáticamente.
- La AP es una aproximación declarada; en producción va la tabla completa del manual.
- Lecturas y revisiones son append-only.
- Los rangos de la línea demo son de ejemplo; sustituir por fichas técnicas reales antes de demos con cliente.
