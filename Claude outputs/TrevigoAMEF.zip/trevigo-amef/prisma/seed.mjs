import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();
const INITIAL_PASSWORD = process.env.SEED_PASSWORD || "trevigo2026";

// ─── Utilidades ──────────────────────────────────────────────────────────────
const DIAS = 96; // turnos registrados (1 chequeo/día para la demo)
const hoy = new Date();
function diaN(n) {
  // n = 0 es el turno más antiguo; n = DIAS-1 es hoy
  const d = new Date(hoy);
  d.setDate(d.getDate() - (DIAS - 1 - n));
  d.setHours(8, 0, 0, 0);
  return d;
}
function ruido(base, amp, n, fase = 0) {
  return Math.round((base + amp * Math.sin(n / 7 + fase) + amp * 0.5 * Math.sin(n / 3 + fase * 2)) * 100) / 100;
}

async function main() {
  // ── Usuarios ──
  const hash = await bcrypt.hash(INITIAL_PASSWORD, 10);
  const usuarios = [
    { email: "hernan.trevino@trevigo.com.mx", name: "Hernán Treviño", role: "ADMIN" },
    { email: "blanca@trevigo.com.mx", name: "Blanca", role: "USUARIO" },
    { email: "norma@trevigo.com.mx", name: "Norma", role: "USUARIO" },
  ];
  for (const u of usuarios) {
    await prisma.user.upsert({ where: { email: u.email }, update: {}, create: { ...u, passwordHash: hash } });
  }

  // ── Planta y línea de demostración (línea GENÉRICA — sección 12.2; nada de datos de clientes reales) ──
  const yaExiste = await prisma.linea.findFirst();
  if (yaExiste) {
    console.log("Ya hay una línea sembrada; no se duplica. (Borra la base si quieres re-sembrar.)");
    return;
  }

  const planta = await prisma.planta.create({
    data: { nombre: "Planta de Demostración", ciudad: "Monterrey, NL", esDemo: true },
  });

  const linea = await prisma.linea.create({
    data: {
      plantaId: planta.id,
      nombre: "Línea 2 — Fosfato de zinc, 7 etapas",
      topologia: "fosfato de zinc · 7 etapas",
      familiaQuimica: "zinc",
      nEtapas: 7,
      tieneActivador: true,
      tieneSellador: true,
      frecuenciaChequeoH: 8,
    },
  });

  // ── Parámetros (rangos de EJEMPLO dentro de bandas publicadas; sustituir por fichas técnicas reales) ──
  const P = {};
  const defs = [
    ["deg_c", 1, "Desengrase alcalino", "Concentración", "pts", 15, 22, false, "titulación", 1],
    ["deg_t", 1, "Desengrase alcalino", "Temperatura", "°C", 50, 65, false, null, 2],
    ["act_c", 3, "Activador", "Concentración", "pts", 1.8, 3.0, false, "titulación", 3],
    ["fos_al", 4, "Fosfato de zinc", "Acidez libre", "pts", 5, 8, false, "titulación NaOH", 4],
    ["fos_at", 4, "Fosfato de zinc", "Acidez total", "pts", 38, 48, false, "titulación NaOH", 5],
    ["fos_t", 4, "Fosfato de zinc", "Temperatura", "°C", 45, 60, false, null, 6],
    ["fos_fe", 4, "Fosfato de zinc", "Hierro disuelto", "%", null, 0.40, true, "permanganato", 7],
    ["sel_c", 7, "Sellador", "Concentración", "pts", 1.0, 2.0, false, "titulación", 8],
    ["pt_pc", 8, "Producto terminado", "Peso de capa", "g/m²", 1.8, 4.5, false, "decapado y pesaje", 9],
  ];
  for (const [key, etapaNum, etapaNombre, nombre, unidad, specMin, specMax, esMaximo, metodo, orden] of defs) {
    P[key] = await prisma.parametro.create({
      data: { lineaId: linea.id, etapaNum, etapaNombre, nombre, unidad, specMin, specMax, esMaximo, metodo, orden },
    });
  }

  // ── Generadores de valores por día ──
  // Historia: hierro disuelto sube lentamente (baño envejeciendo) con 5 excursiones fuera de rango,
  // y HOY viene en deriva (0.37, subiendo). Desengrase: 3 caídas históricas y HOY fuera de spec (14.6).
  const feFuera = new Set([22, 39, 55, 68, 81]); // días con hierro > 0.40
  const degFuera = new Set([30, 61, 78]); // caídas históricas de concentración
  const gen = {
    deg_c: (n) => (n === DIAS - 1 ? 14.6 : degFuera.has(n) ? 14.4 : ruido(18.5, 1.6, n)),
    deg_t: (n) => ruido(57, 3.2, n, 1),
    act_c: (n) => ruido(2.4, 0.28, n, 2),
    fos_al: (n) => ruido(6.4, 0.7, n, 3),
    fos_at: (n) => ruido(43, 2.4, n, 4),
    fos_t: (n) => ruido(52, 3.5, n, 5),
    fos_fe: (n) => {
      if (feFuera.has(n)) return 0.43;
      if (n >= DIAS - 4) return [0.28, 0.31, 0.34, 0.37][n - (DIAS - 4)]; // deriva actual
      return Math.min(0.36, Math.round((0.18 + n * 0.0016 + 0.03 * Math.sin(n / 5)) * 100) / 100);
    },
    sel_c: (n) => ruido(1.5, 0.18, n, 6),
    pt_pc: (n) => ruido(3.1, 0.5, n, 7),
  };
  function estadoDe(key, v) {
    const p = P[key];
    if (p.esMaximo) return v > p.specMax ? "fuera_spec" : "en_spec";
    return v < p.specMin || v > p.specMax ? "fuera_spec" : "en_spec";
  }

  // ── Turnos + lecturas ──
  const turnos = [];
  for (let n = 0; n < DIAS; n++) {
    const t = await prisma.turno.create({
      data: {
        lineaId: linea.id,
        fecha: diaN(n),
        operador: "Operador demo",
        iniciadoEn: diaN(n),
        terminadoEn: new Date(diaN(n).getTime() + 55 * 1000),
        duracionSeg: 38 + ((n * 7) % 28),
        completo: true,
      },
    });
    turnos.push(t);
  }
  const filas = [];
  for (let n = 0; n < DIAS; n++) {
    for (const key of Object.keys(gen)) {
      const v = gen[key](n);
      filas.push({
        parametroId: P[key].id,
        turnoId: turnos[n].id,
        valor: v,
        estado: estadoDe(key, v),
        capturadoPor: "Operador demo",
        capturadoEn: new Date(diaN(n).getTime() + 30 * 1000),
      });
    }
  }
  await prisma.lectura.createMany({ data: filas });

  // ── AMEF: catálogo semilla FILTRADO por topología (zinc, 7 etapas, con activador y sellador) ──
  async function modo(orden, paso, nombre, efecto, S, puntoCiego, causas) {
    const m = await prisma.modoDeFalla.create({
      data: { lineaId: linea.id, paso, modo: nombre, efecto, severidad: S, puntoCiego, orden },
    });
    const out = [];
    for (const c of causas) {
      out.push(
        await prisma.causa.create({
          data: {
            modoId: m.id,
            descripcion: c.d,
            categoria4m: c.cat,
            ocurrencia: c.O,
            deteccion: c.D,
            controlesPrevencion: c.prev ?? [],
            controlesDeteccion: c.det ?? [],
            parametros: { connect: (c.params ?? []).map((k) => ({ id: P[k].id })) },
          },
        })
      );
    }
    return { m, causas: out };
  }

  const m1 = await modo(1, "Desengrase", "Limpieza insuficiente",
    "Falla de adherencia de pintura · rechazo del cliente", 8, null, [
      { d: "Concentración de desengrase baja", cat: "metodo", O: 4, D: 4, prev: ["Dosificación por consumo"], det: ["Titulación cada turno", "Prueba de ruptura de película de agua"], params: ["deg_c"] },
      { d: "Temperatura por debajo de rango", cat: "maquina", O: 3, D: 4, prev: ["Mantenimiento de resistencias"], det: ["Registro de temperatura por turno"], params: ["deg_t"] },
      { d: "Cambio de lubricante en la operación previa", cat: "material", O: 3, D: 6, prev: ["Aviso de cambio de material"], det: ["Nota de voz del técnico"], params: [] },
    ]);

  const m6 = await modo(2, "Activador", "Activador agotado o sin ajuste",
    "Cristal grueso y disparejo · mal anclaje para la pintura", 7, null, [
      { d: "Concentración de activador fuera de rango", cat: "metodo", O: 5, D: 3, prev: ["Reposición programada"], det: ["Concentración de activador por turno"], params: ["act_c"] },
    ]);

  const m7 = await modo(3, "Baño de conversión — fosfato de zinc", "Cristal grueso y disparejo",
    "Aspecto manchado · mal anclaje para pintura", 7, null, [
      { d: "Relación acidez total : libre fuera de rango", cat: "metodo", O: 4, D: 3, prev: ["Ajuste por titulación"], det: ["Titulación de acidez libre y total"], params: ["fos_al", "fos_at"] },
      { d: "Temperatura de baño baja", cat: "maquina", O: 3, D: 3, prev: ["Control de temperatura"], det: ["Registro de temperatura por turno"], params: ["fos_t"] },
    ]);

  const m9 = await modo(4, "Baño de conversión — fosfato de zinc", "Manchado amarillo",
    "Rechazo estético · señal de baño agotado", 5, null, [
      { d: "Hierro disuelto acumulado por encima del límite", cat: "material", O: 4, D: 3, prev: ["Decantación programada"], det: ["Titulación de hierro por permanganato"], params: ["fos_fe"] },
    ]);

  const m10 = await modo(5, "Baño de conversión — fosfato de zinc", "Peso de capa bajo",
    "Baja resistencia a corrosión · falla en cámara salina", 7, null, [
      { d: "Baño agotado / acidez libre alta", cat: "material", O: 3, D: 4, prev: ["Reposición por consumo"], det: ["Peso de capa por decapado y pesaje", "Titulaciones"], params: ["pt_pc", "fos_al", "fos_t"] },
    ]);

  const m13 = await modo(6, "Sellador", "Sellador agotado",
    "Baja resistencia a corrosión sin señal visible", 7,
    "La falla no se ve hasta la cámara salina o hasta el campo.", [
      { d: "Concentración de sellador fuera de rango", cat: "metodo", O: 3, D: 5, prev: ["Reposición programada"], det: ["Concentración de sellador por turno"], params: ["sel_c"] },
    ]);

  const m16 = await modo(7, "Aplicación de pintura", "Espesor fuera de rango",
    "Cobertura despareja · bajo desempeño en corrosión · desperdicio de pintura", 6,
    "No hay ningún parámetro de aplicación en el registro: ni espesor, ni humedad de cabina, ni ajuste de pistola. Es el modo con la peor detección del catálogo y el mejor argumento de expansión del sistema.", [
      { d: "Ajuste de pistola / condiciones de cabina", cat: "maquina", O: 4, D: 9, prev: [], det: [], params: [] },
    ]);

  const m19 = await modo(8, "Horno de curado", "Curado incompleto",
    "Pintura suave · baja adherencia · falla en campo", 9,
    "Se mide el aire del horno, no la pieza. Sin perfil térmico (data logger que viaja con la pieza) no hay forma de detectarlo antes de que salga.", [
      { d: "Temperatura por debajo de rango", cat: "maquina", O: 3, D: 7, prev: ["Registro de temperatura de horno"], det: [], params: [] },
      { d: "Velocidad de cadena alta", cat: "metodo", O: 3, D: 7, prev: [], det: [], params: [] },
    ]);

  // ── Eventos de causa (lecturas fuera de rango contadas contra turnos registrados) ──
  for (const n of feFuera) {
    await prisma.eventoDeCausa.create({ data: { causaId: m9.causas[0].id, turnoId: turnos[n].id } });
  }
  for (const n of degFuera) {
    await prisma.eventoDeCausa.create({ data: { causaId: m1.causas[0].id, turnoId: turnos[n].id } });
  }
  await prisma.eventoDeCausa.create({ data: { causaId: m1.causas[0].id, turnoId: turnos[DIAS - 1].id } });

  // ── Acciones verificadas → playbook (siempre numerador y denominador; los fracasos también valen) ──
  async function acciones(causaId, texto, ok, no, base = 10) {
    let i = 0;
    for (let k = 0; k < ok + no; k++) {
      const dia = base + i * 6;
      i++;
      await prisma.accion.create({
        data: {
          causaId, descripcion: texto,
          registradaPor: "Téc. Trevigo", registradaEn: diaN(Math.min(dia, DIAS - 6)),
          origen: "nota_voz",
          eficacia: k < ok ? "funciono" : "no_funciono",
          verificadaPor: "Calidad", verificadaEn: diaN(Math.min(dia + 2, DIAS - 4)),
        },
      });
    }
  }
  await acciones(m7.causas[0].id, "Ajustar el activador", 11, 2, 5);
  await acciones(m7.causas[0].id, "Bajar acidez libre", 3, 5, 8);
  await acciones(m7.causas[1].id, "Subir temperatura del baño", 1, 1, 12);
  await acciones(m9.causas[0].id, "Decantar el baño", 4, 1, 15);
  await acciones(m19.causas[1].id, "Bajar velocidad de cadena", 2, 0, 20);
  await acciones(m19.causas[0].id, "Subir temperatura de curado", 1, 1, 25);

  // Una acción SIN verificar, con más de 48 h → aparece en la bandeja como "¿Funcionó?"
  await prisma.accion.create({
    data: {
      causaId: m9.causas[0].id,
      descripcion: "Decantar el baño de fosfato",
      deValor: "0.43", aValor: "0.28",
      registradaPor: "Téc. Trevigo", origen: "nota_voz",
      registradaEn: new Date(Date.now() - 72 * 3600 * 1000),
    },
  });

  // ── Propuesta de revisión pendiente (el sistema PROPONE; una persona firma) ──
  // 5 eventos de hierro en 96 turnos = 1 de cada 19 ≈ nivel 6; la asignada es 4 → diferencia ≥ 2 → se propone.
  await prisma.propuestaRevision.create({
    data: {
      causaId: m9.causas[0].id,
      tipoRating: "O",
      valorActual: 4,
      valorPropuesto: 6,
      evidencia: [
        "5 eventos de causa (hierro disuelto > 0.40%) en 96 turnos registrados = 1 de cada 19 turnos.",
        "La ocurrencia vigente (4) corresponde a ~1 de cada 100 turnos — lo observado es 5 veces más frecuente.",
        "La tendencia de los últimos 4 turnos va subiendo (0.28 → 0.37) con el parámetro en deriva.",
      ],
      fuente: `Bitácora Línea 2 · ${diaN(0).toLocaleDateString("es-MX", { month: "short", year: "numeric" })} – ${hoy.toLocaleDateString("es-MX", { month: "short", year: "numeric" })} · 96 turnos`,
      apAntes: "M",
      apDespues: "A",
    },
  });

  // ── Historial de revisiones firmadas (incluye un rechazo: también es evidencia, cláusula 6.1) ──
  await prisma.revisionAmef.create({
    data: {
      modoId: m7.m.id, causaId: m7.causas[0].id,
      tipoRating: "O", deValor: 5, aValor: 4,
      evidenciaResumen: "Control de reposición por titulación vigente 90 turnos; 2 eventos en 190 turnos desde el cambio de control",
      aprobadaPor: "Ing. M. Salinas · Calidad",
      aprobadaEn: diaN(40),
      numeroRevision: 1,
    },
  });
  await prisma.revisionAmef.create({
    data: {
      modoId: m1.m.id, causaId: m1.causas[0].id,
      sinCambio: true,
      evidenciaResumen: "Propuesta revisada; se conserva la ocurrencia vigente",
      aprobadaPor: "Ing. R. Domínguez · Calidad",
      aprobadaEn: diaN(85),
      numeroRevision: 1,
    },
  });

  console.log("Planta de demostración sembrada:");
  console.log("· Línea genérica de fosfato de zinc, 7 etapas (9 parámetros)");
  console.log("· 96 turnos de bitácora, 8 modos de falla, playbook con conteos");
  console.log("· 1 propuesta pendiente de firma, 1 parámetro en deriva, 1 fuera de spec");
  console.log("Usuarios: hernan.trevino@ / blanca@ / norma@trevigo.com.mx · contraseña:", INITIAL_PASSWORD);
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
