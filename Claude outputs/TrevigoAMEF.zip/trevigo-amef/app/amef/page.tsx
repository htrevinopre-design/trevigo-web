import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import Shell from "@/components/Shell";
import { getLinea, getParametrosConEstado, getModosVista } from "@/lib/queries";
import { aprobarPropuesta, rechazarPropuesta } from "@/lib/actions";
import { apOf, AP_CLASS, ESTADO_LABEL, fmtFecha } from "@/lib/amef";
import type { ParamStatus } from "@/lib/amef";

export const dynamic = "force-dynamic";

export default async function AmefPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  const linea = await getLinea();
  if (!linea) redirect("/");

  const params = await getParametrosConEstado(linea.id);
  const estadoMap = new Map<string, ParamStatus>(params.map((p) => [p.id, p.estado]));
  const paramById = new Map(params.map((p) => [p.id, p]));
  const modos = await getModosVista(linea.id, estadoMap);

  return (
    <Shell
      session={session}
      linea={{ nombre: linea.nombre, topologia: linea.topologia, plantaNombre: linea.planta.nombre, esDemo: linea.planta.esDemo }}
    >
      <h1 className="text-xl font-black text-petrol-950 mb-1">AMEF vivo</h1>
      <p className="text-sm text-slate-500 mb-6">
        AMEF de proceso sustentado en la bitácora de la línea. La ocurrencia se asigna a la causa (AIAG-VDA) y se
        contrasta contra los eventos observados: lecturas fuera de rango sobre turnos registrados.
      </p>

      <div className="space-y-6">
        {modos.map((m) => (
          <div key={m.id} className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            {/* Header del modo */}
            <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-[11px] uppercase tracking-wider font-bold text-slate-400">{m.paso}</p>
                <h2 className="font-black text-lg text-slate-900">{m.modo}</h2>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono bg-slate-100 border border-slate-200 rounded px-2 py-1">S {m.severidad}</span>
                <span
                  className={`text-xs font-black uppercase tracking-wide rounded-full px-3 py-1 border ${
                    m.estado === "ok" ? "bg-emerald-50 text-emerald-700 border-emerald-200" :
                    m.estado === "hit" ? "bg-red-50 text-red-700 border-red-200" :
                    m.estado === "drift" ? "bg-amber-50 text-amber-700 border-amber-200" :
                    "bg-slate-100 text-slate-500 border-slate-200"
                  }`}
                >
                  {ESTADO_LABEL[m.estado]}
                </span>
              </div>
            </div>

            <div className="p-5 grid grid-cols-1 lg:grid-cols-2 gap-5">
              {/* Izquierda: efecto y causas */}
              <div>
                <p className="text-[11px] uppercase tracking-wider font-bold text-slate-400 mb-1">Efecto (S {m.severidad})</p>
                <p className="text-sm text-slate-700 mb-4">{m.efecto}</p>

                <p className="text-[11px] uppercase tracking-wider font-bold text-slate-400 mb-2">Causas</p>
                <div className="space-y-3">
                  {m.causas.map((c) => {
                    const ap = apOf(m.severidad, c.ocurrencia, c.deteccion);
                    return (
                      <div key={c.id} className="border border-slate-200 rounded-lg p-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <p className="text-sm font-semibold text-slate-800">{c.descripcion}</p>
                          <div className="flex gap-1.5">
                            <span className="text-[11px] font-mono bg-slate-100 rounded px-1.5 py-0.5">O {c.ocurrencia}</span>
                            <span className="text-[11px] font-mono bg-slate-100 rounded px-1.5 py-0.5">D {c.deteccion}</span>
                            <span className={`text-[11px] font-black rounded px-1.5 py-0.5 border ${AP_CLASS[ap]}`}>AP {ap}</span>
                          </div>
                        </div>
                        {c.eventos > 0 && (
                          <p className="text-[11px] text-slate-500 mt-1">{c.eventos} eventos de causa registrados por la bitácora</p>
                        )}
                        {c.paramIds.length > 0 && (
                          <div className="flex flex-wrap gap-1.5 mt-2">
                            {c.paramIds.map((pid) => {
                              const p = paramById.get(pid);
                              if (!p) return null;
                              const dot = p.estado === "cr" ? "bg-red-500" : p.estado === "wa" ? "bg-amber-400" : "bg-emerald-500";
                              return (
                                <span key={pid} className="inline-flex items-center gap-1.5 text-[11px] text-slate-600 bg-slate-50 border border-slate-200 rounded-full px-2 py-0.5">
                                  <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />
                                  {p.nombre}
                                </span>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Derecha: controles, playbook, punto ciego, propuesta */}
              <div className="space-y-4">
                <div>
                  <p className="text-[11px] uppercase tracking-wider font-bold text-slate-400 mb-1">Controles</p>
                  <ul className="text-sm text-slate-600 space-y-0.5">
                    {Array.from(new Set(m.causas.flatMap((c) => [...c.controlesPrevencion, ...c.controlesDeteccion]))).map((ctrl) => (
                      <li key={ctrl}>· {ctrl}</li>
                    ))}
                  </ul>
                </div>

                {m.playbook.length > 0 && (
                  <div>
                    <p className="text-[11px] uppercase tracking-wider font-bold text-slate-400 mb-2">
                      Playbook — qué ha funcionado
                    </p>
                    <div className="space-y-1.5">
                      {m.playbook.map((e) => {
                        const total = e.ok + e.no;
                        const pct = total ? Math.round((e.ok / total) * 100) : 0;
                        return (
                          <div key={e.accion}>
                            <div className="flex justify-between text-xs mb-0.5">
                              <span className="text-slate-700">{e.accion}</span>
                              <span className="font-mono font-bold text-slate-600">{e.ok}/{total}</span>
                            </div>
                            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                              <div className="h-full bg-petrol-600" style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {m.puntoCiego && (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                    <p className="text-[11px] uppercase tracking-wider font-black text-amber-700 mb-1">Punto ciego</p>
                    <p className="text-sm text-amber-900">{m.puntoCiego}</p>
                  </div>
                )}

                {m.causas.filter((c) => c.propuesta).map((c) => {
                  const pr = c.propuesta!;
                  return (
                    <div key={pr.id} className="border-2 border-petrol-600 rounded-xl p-4 bg-petrol-50">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <p className="text-[11px] uppercase tracking-wider font-black text-petrol-700">
                          Propuesta de revisión · pendiente
                        </p>
                        <p className="text-sm font-black text-petrol-950">
                          {pr.tipoRating === "O" ? "Ocurrencia" : "Detección"} {pr.valorActual} → {pr.valorPropuesto}
                          <span className="ml-3 font-bold text-petrol-700">
                            {pr.apAntes === pr.apDespues ? `AP se mantiene en ${pr.apAntes}` : `AP ${pr.apAntes} → ${pr.apDespues}`}
                          </span>
                        </p>
                      </div>
                      <p className="text-xs text-slate-500 mb-1">Causa: {c.descripcion}</p>
                      <ul className="text-sm text-slate-700 space-y-1 mb-2">
                        {pr.evidencia.map((ev, i) => (
                          <li key={i}>· {ev}</li>
                        ))}
                      </ul>
                      <p className="text-[11px] text-slate-500 mb-3">Fuente: {pr.fuente}</p>
                      <div className="flex gap-2">
                        <form action={aprobarPropuesta.bind(null, pr.id)}>
                          <button className="bg-petrol-600 hover:bg-petrol-700 text-white text-sm font-black px-5 py-2 rounded-lg">
                            Aprobar y firmar
                          </button>
                        </form>
                        <form action={rechazarPropuesta.bind(null, pr.id)}>
                          <button className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-sm font-black px-5 py-2 rounded-lg">
                            No procede
                          </button>
                        </form>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Historial de revisiones firmadas */}
            {m.revisiones.length > 0 && (
              <div className="border-t border-slate-100 px-5 py-3 bg-slate-50">
                <p className="text-[11px] uppercase tracking-wider font-bold text-slate-400 mb-2">Historial de revisiones</p>
                <ul className="space-y-1">
                  {m.revisiones.map((r, i) => (
                    <li key={i} className="text-xs text-slate-600 flex flex-wrap items-center gap-2">
                      {r.sinCambio ? (
                        <span className="font-mono bg-slate-200 text-slate-500 rounded px-1.5 py-0.5">Sin cambio</span>
                      ) : (
                        <span className="font-mono bg-petrol-100 text-petrol-800 rounded px-1.5 py-0.5">
                          {r.tipoRating} {r.deValor} → {r.aValor}
                        </span>
                      )}
                      <span>{r.evidenciaResumen}</span>
                      <span className="text-slate-400">— {r.aprobadaPor} · {fmtFecha(r.aprobadaEn)} · Rev. {r.numeroRevision}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </Shell>
  );
}
