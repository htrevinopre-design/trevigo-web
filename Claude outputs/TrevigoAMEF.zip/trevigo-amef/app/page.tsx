import Link from "next/link";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import Shell from "@/components/Shell";
import { getLinea, getParametrosConEstado, getModosVista, getPendientes48h, getTurnosRegistrados } from "@/lib/queries";
import { responderEficacia, registrarAccion } from "@/lib/actions";
import { fmtFechaHora } from "@/lib/amef";
import type { ParamStatus } from "@/lib/amef";

export const dynamic = "force-dynamic";

export default async function Bandeja() {
  const session = await getSession();
  if (!session) redirect("/login");

  const linea = await getLinea();
  if (!linea) {
    return (
      <Shell session={session}>
        <p className="text-slate-500">No hay líneas configuradas. Corre el seed de la base de datos.</p>
      </Shell>
    );
  }

  const params = await getParametrosConEstado(linea.id);
  const estadoMap = new Map<string, ParamStatus>(params.map((p) => [p.id, p.estado]));
  const [modos, pendientes48, turnosRegistrados] = await Promise.all([
    getModosVista(linea.id, estadoMap),
    getPendientes48h(),
    getTurnosRegistrados(linea.id),
  ]);

  const fueraSpec = params.filter((p) => p.estado === "cr");
  const enDeriva = params.filter((p) => p.estado === "wa");
  const propuestas = modos.flatMap((m) => m.causas.filter((c) => c.propuesta).map((c) => ({ modo: m, causa: c })));

  const protegidos = modos.filter((m) => m.estado === "ok").length;
  const comprometidos = modos.filter((m) => m.estado === "hit").length;
  const sinControl = modos.filter((m) => m.estado === "gap" || m.puntoCiego).length;

  const bandejaVacia =
    fueraSpec.length === 0 && enDeriva.length === 0 && pendientes48.length === 0 && propuestas.length === 0;

  return (
    <Shell
      session={session}
      linea={{ nombre: linea.nombre, topologia: linea.topologia, plantaNombre: linea.planta.nombre, esDemo: linea.planta.esDemo }}
    >
      {/* Resumen */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <Stat label="Modos protegidos" value={protegidos} tone="ok" />
        <Stat label="Control comprometido ahora" value={comprometidos} tone={comprometidos ? "bad" : "muted"} />
        <Stat label="Sin control en el registro" value={sinControl} tone={sinControl ? "warn" : "muted"} />
        <Stat label="Propuestas por aprobar" value={propuestas.length} tone={propuestas.length ? "brand" : "muted"} />
      </div>

      <div className="flex items-baseline justify-between mb-3">
        <h1 className="text-xl font-black text-petrol-950">Bandeja de calidad</h1>
        <span className="text-xs text-slate-400">{turnosRegistrados} turnos con bitácora completa</span>
      </div>

      {bandejaVacia && (
        <div className="bg-white border border-slate-200 rounded-xl p-8 text-center">
          <p className="text-emerald-700 font-bold mb-1">Bandeja vacía</p>
          <p className="text-slate-500 text-sm">Nada requiere tu atención en este momento. Los días buenos se ven así.</p>
        </div>
      )}

      <div className="space-y-4">
        {/* 1. Fuera de especificación */}
        {fueraSpec.map((p) => (
          <div key={p.id} className="bg-white border-l-4 border-red-500 border border-slate-200 rounded-xl p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <p className="font-bold text-slate-900">
                <span className="text-red-600 font-black uppercase text-xs tracking-wider mr-2">Fuera de especificación</span>
                Etapa {p.etapaNum} · {p.etapaNombre} — {p.nombre}
              </p>
              <p className="font-mono text-sm">
                <span className="text-red-600 font-bold">{p.ultimo}</span>
                <span className="text-slate-400"> {p.unidad} · spec {p.esMaximo ? `máx ${p.specMax}` : `${p.specMin} – ${p.specMax}`}</span>
              </p>
            </div>
            <details className="mt-2">
              <summary className="text-sm text-petrol-600 font-bold cursor-pointer">Registrar acción tomada</summary>
              <div className="mt-3 space-y-3">
                {modos
                  .flatMap((m) => m.causas.map((c) => ({ m, c })))
                  .filter(({ c }) => c.paramIds.includes(p.id))
                  .map(({ m, c }) => (
                    <form key={c.id} action={registrarAccion.bind(null, c.id)} className="flex flex-wrap gap-2 items-center">
                      <span className="text-xs text-slate-500 w-full sm:w-auto">
                        {m.modo} → <strong>{c.descripcion}</strong>:
                      </span>
                      <input name="descripcion" required placeholder="¿Qué se hizo? (ej. Ajustar concentración)" className="border border-slate-300 rounded px-2 py-1 text-sm flex-1 min-w-[200px]" />
                      <input name="deValor" placeholder="de" className="border border-slate-300 rounded px-2 py-1 text-sm w-16" />
                      <input name="aValor" placeholder="a" className="border border-slate-300 rounded px-2 py-1 text-sm w-16" />
                      <button className="bg-petrol-600 hover:bg-petrol-700 text-white text-xs font-bold px-3 py-1.5 rounded">Registrar</button>
                    </form>
                  ))}
              </div>
            </details>
          </div>
        ))}

        {/* 2. En deriva */}
        {enDeriva.map((p) => {
          const span = (p.specMax ?? 0) - (p.specMin ?? 0);
          const cercaSuperior = p.specMax !== null && p.ultimo !== null && p.ultimo > p.specMax - span * 0.18;
          return (
            <div key={p.id} className="bg-white border-l-4 border-amber-400 border border-slate-200 rounded-xl p-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="font-bold text-slate-900">
                  <span className="text-amber-600 font-black uppercase text-xs tracking-wider mr-2">En deriva</span>
                  Etapa {p.etapaNum} · {p.etapaNombre} — {p.nombre}
                </p>
                <p className="font-mono text-sm text-slate-600">
                  {p.ultimo} {p.unidad}
                </p>
              </div>
              <p className="text-sm text-slate-500 mt-1">
                Dentro de especificación, pero cerca del límite {cercaSuperior ? "superior" : "inferior"} y{" "}
                <strong>{p.tendencia === "subiendo" ? "subiendo" : "bajando"}</strong> en los últimos turnos
                {" "}(historial: {p.hist.join(" → ")}). Conviene actuar antes de que salga.
              </p>
            </div>
          );
        })}

        {/* 3. ¿Funcionó? — la pregunta de 48 horas */}
        {pendientes48.map((a) => (
          <div key={a.id} className="bg-white border-l-4 border-petrol-600 border border-slate-200 rounded-xl p-4">
            <p className="font-bold text-slate-900 mb-1">
              <span className="text-petrol-600 font-black uppercase text-xs tracking-wider mr-2">Verificación de eficacia</span>
              ¿Funcionó “{a.descripcion}”?
            </p>
            <p className="text-sm text-slate-500 mb-3">
              {a.causa.modo.modo} → {a.causa.descripcion} · registrada por {a.registradaPor} el {fmtFechaHora(a.registradaEn)}
              {a.deValor && a.aValor ? ` · ${a.deValor} → ${a.aValor}` : ""}
            </p>
            <div className="flex gap-2">
              <form action={responderEficacia.bind(null, a.id, true)}>
                <button className="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-black px-6 py-2 rounded-lg">Sí, funcionó</button>
              </form>
              <form action={responderEficacia.bind(null, a.id, false)}>
                <button className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-sm font-black px-6 py-2 rounded-lg">No funcionó</button>
              </form>
            </div>
          </div>
        ))}

        {/* 4. Propuestas pendientes */}
        {propuestas.length > 0 && (
          <div className="bg-white border-l-4 border-petrol-800 border border-slate-200 rounded-xl p-4">
            <p className="font-bold text-slate-900">
              <span className="text-petrol-800 font-black uppercase text-xs tracking-wider mr-2">AMEF</span>
              {propuestas.length === 1 ? "1 propuesta de revisión pendiente" : `${propuestas.length} propuestas de revisión pendientes`} de firma
            </p>
            <p className="text-sm text-slate-500 mt-1 mb-2">
              {propuestas.map(({ modo, causa }) => `${modo.modo} (${causa.propuesta!.tipoRating} ${causa.propuesta!.valorActual} → ${causa.propuesta!.valorPropuesto})`).join(" · ")}
            </p>
            <Link href="/amef" className="text-petrol-600 font-bold text-sm hover:underline">Revisar en el AMEF vivo →</Link>
          </div>
        )}
      </div>
    </Shell>
  );
}

function Stat({ label, value, tone }: { label: string; value: number; tone: "ok" | "bad" | "warn" | "brand" | "muted" }) {
  const cls =
    tone === "ok" ? "text-emerald-700" :
    tone === "bad" ? "text-red-600" :
    tone === "warn" ? "text-amber-600" :
    tone === "brand" ? "text-petrol-600" : "text-slate-400";
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4">
      <p className="text-[11px] uppercase tracking-wide font-bold text-slate-400">{label}</p>
      <p className={`text-2xl font-black ${cls}`}>{value}</p>
    </div>
  );
}
