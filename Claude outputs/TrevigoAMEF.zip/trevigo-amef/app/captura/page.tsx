import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import Shell from "@/components/Shell";
import { getLinea, getParametrosConEstado } from "@/lib/queries";
import { registrarTurno } from "@/lib/actions";
import CapturaForm from "@/components/CapturaForm";

export const dynamic = "force-dynamic";

export default async function CapturaPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  const linea = await getLinea();
  if (!linea) redirect("/");

  const params = await getParametrosConEstado(linea.id);

  return (
    <Shell
      session={session}
      linea={{ nombre: linea.nombre, topologia: linea.topologia, plantaNombre: linea.planta.nombre, esDemo: linea.planta.esDemo }}
    >
      <div className="max-w-2xl mx-auto">
        <h1 className="text-xl font-black text-petrol-950 mb-1">Chequeo de línea</h1>
        <p className="text-sm text-slate-500 mb-5">
          Campos en el orden del recorrido físico de la línea. El formato en papel toma 60–90 segundos — la meta es ganarle.
        </p>
        <CapturaForm
          action={registrarTurno.bind(null, linea.id)}
          params={params.map((p) => ({
            id: p.id,
            etapaNum: p.etapaNum,
            etapaNombre: p.etapaNombre,
            nombre: p.nombre,
            unidad: p.unidad,
            specText: p.esObservacion
              ? "campo libre"
              : p.esMaximo
                ? `máx ${p.specMax}`
                : `${p.specMin} – ${p.specMax}`,
            anterior: p.ultimo,
          }))}
        />
      </div>
    </Shell>
  );
}
