import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        petrol: {
          50: "#eef7f8",
          100: "#d5ecee",
          600: "#0d6e7a",
          700: "#0a5a64",
          800: "#08464e",
          900: "#062f35",
          950: "#041f23",
        },
        navy: {
          600: "#1e3a5f",
          800: "#122a47",
          900: "#0c1f36",
          950: "#081527",
        },
      },
    },
  },
  plugins: [],
};
export default config;
