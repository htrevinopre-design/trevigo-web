import { prisma } from "@/lib/db";
import { statusOf, modeState, type ParamStatus, type ModeState } from "@/lib/amef";

export type ParamConEstado = {
  id: string;
  etapaNum: number;
  etapaNombre: string;
  nombre: string;
  unidad: string;
  specMin: number | null;
  specMax: number | null;
  esMaximo: boolean;
  metodo: string | null;
  esObservacion: boolean;
  orden: number;
  ultimo: number | null;
  anterior: number | null;
  hist: number[];
  estado: ParamStatus;
  tendencia: "subiendo" | "bajando" | null;
};

export async function getLinea() {
  return prisma.linea.findFirst({ include: { planta: true } });
}

export async function getParametrosConEstado(lineaId: string): Promise<ParamConEstado[]> {
  const params = await prisma.parametro.findMany({
    where: { lineaId },
    orderBy: { orden: "asc" },
    include: { lecturas: { orderBy: { capturadoEn: "desc" }, take: 4 } },
  });

  return params.map((p) => {
    const histDesc = p.lecturas.map((l) => l.valor);
    const hist = [...histDesc].reverse(); // cronológico
    const ultimo = hist.length ? hist[hist.length - 1] : null;
    const anterior = hist.length > 1 ? hist[hist.length - 2] : null;
    const estado = p.esObservacion
      ? ("na" as ParamStatus)
      : statusOf(ultimo, p.specMin, p.specMax, p.esMaximo, hist.slice(0, -1).slice(-3));
    let tendencia: "subiendo" | "bajando" | null = null;
    if (hist.length >= 2) tendencia = hist[hist.length - 1] > hist[0] ? "subiendo" : hist[hist.length - 1] < hist[0] ? "bajando" : null;
    return {
      id: p.id, etapaNum: p.etapaNum, etapaNombre: p.etapaNombre, nombre: p.nombre,
      unidad: p.unidad, specMin: p.specMin, specMax: p.specMax, esMaximo: p.esMaximo,
      metodo: p.metodo, esObservacion: p.esObservacion, orden: p.orden,
      ultimo, anterior, hist, estado, tendencia,
    };
  });
}

export type PlaybookEntry = { accion: string; ok: number; no: number };

export type CausaVista = {
  id: string;
  descripcion: string;
  categoria4m: string;
  ocurrencia: number;
  deteccion: number;
  controlesPrevencion: string[];
  controlesDeteccion: string[];
  paramIds: string[];
  eventos: number;
  propuesta: {
    id: string; tipoRating: string; valorActual: number; valorPropuesto: number;
    evidencia: string[]; fuente: string; apAntes: string; apDespues: string;
  } | null;
};

export type ModoVista = {
  id: string;
  paso: string;
  modo: string;
  efecto: string;
  severidad: number;
  puntoCiego: string | null;
  estado: ModeState;
  causas: CausaVista[];
  playbook: PlaybookEntry[];
  revisiones: {
    tipoRating: string | null; deValor: number | null; aValor: number | null;
    sinCambio: boolean; evidenciaResumen: string; aprobadaPor: string;
    aprobadaEn: Date; numeroRevision: number;
  }[];
};

export async function getModosVista(lineaId: string, paramEstados: Map<string, ParamStatus>): Promise<ModoVista[]> {
  const modos = await prisma.modoDeFalla.findMany({
    where: { lineaId },
    orderBy: { orden: "asc" },
    include: {
      causas: {
        include: {
          parametros: { select: { id: true } },
          _count: { select: { eventos: true } },
          propuestas: { where: { estado: "pendiente" }, take: 1 },
          acciones: { select: { descripcion: true, eficacia: true } },
        },
      },
      revisiones: { orderBy: { aprobadaEn: "desc" } },
    },
  });

  return modos.map((m) => {
    const allParamIds = m.causas.flatMap((c) => c.parametros.map((p) => p.id));
    const statuses = Array.from(new Set(allParamIds)).map((id) => paramEstados.get(id) ?? "na");
    const withSpec = statuses.filter((s) => s !== "na");
    const estado = modeState(withSpec as ParamStatus[]);

    // playbook: conteo por texto de acción (verificadas)
    const pb = new Map<string, { ok: number; no: number }>();
    for (const c of m.causas) {
      for (const a of c.acciones) {
        if (!a.eficacia) continue;
        const e = pb.get(a.descripcion) ?? { ok: 0, no: 0 };
        if (a.eficacia === "funciono") e.ok++; else e.no++;
        pb.set(a.descripcion, e);
      }
    }
    const playbook: PlaybookEntry[] = Array.from(pb.entries())
      .map(([accion, v]) => ({ accion, ...v }))
      .sort((a, b) => b.ok / (b.ok + b.no || 1) - a.ok / (a.ok + a.no || 1));

    return {
      id: m.id, paso: m.paso, modo: m.modo, efecto: m.efecto,
      severidad: m.severidad, puntoCiego: m.puntoCiego, estado,
      causas: m.causas.map((c) => ({
        id: c.id, descripcion: c.descripcion, categoria4m: c.categoria4m,
        ocurrencia: c.ocurrencia, deteccion: c.deteccion,
        controlesPrevencion: c.controlesPrevencion, controlesDeteccion: c.controlesDeteccion,
        paramIds: c.parametros.map((p) => p.id),
        eventos: c._count.eventos,
        propuesta: c.propuestas[0]
          ? {
              id: c.propuestas[0].id, tipoRating: c.propuestas[0].tipoRating,
              valorActual: c.propuestas[0].valorActual, valorPropuesto: c.propuestas[0].valorPropuesto,
              evidencia: c.propuestas[0].evidencia, fuente: c.propuestas[0].fuente,
              apAntes: c.propuestas[0].apAntes, apDespues: c.propuestas[0].apDespues,
            }
          : null,
      })),
      playbook,
      revisiones: m.revisiones.map((r) => ({
        tipoRating: r.tipoRating, deValor: r.deValor, aValor: r.aValor, sinCambio: r.sinCambio,
        evidenciaResumen: r.evidenciaResumen, aprobadaPor: r.aprobadaPor,
        aprobadaEn: r.aprobadaEn, numeroRevision: r.numeroRevision,
      })),
    };
  });
}

export async function getPendientes48h() {
  const hace48h = new Date(Date.now() - 48 * 3600 * 1000);
  return prisma.accion.findMany({
    where: { eficacia: null, registradaEn: { lte: hace48h } },
    include: { causa: { include: { modo: true } } },
    orderBy: { registradaEn: "asc" },
  });
}

export async function getTurnosRegistrados(lineaId: string) {
  return prisma.turno.count({ where: { lineaId, completo: true } });
}
