"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { statusOf, apOf } from "@/lib/amef";

async function requireSession() {
  const session = await getSession();
  if (!session) redirect("/login");
  return session;
}

/** Captura del operador: crea turno + lecturas, computa estado, genera eventos de causa. */
export async function registrarTurno(lineaId: string, formData: FormData) {
  const session = await requireSession();
  const duracionSeg = parseInt(String(formData.get("duracionSeg") || "0"), 10) || null;

  const params = await prisma.parametro.findMany({
    where: { lineaId },
    include: { lecturas: { orderBy: { capturadoEn: "desc" }, take: 3 }, causas: { select: { id: true } } },
  });

  const turno = await prisma.turno.create({
    data: {
      lineaId,
      fecha: new Date(),
      operador: session.name,
      terminadoEn: new Date(),
      duracionSeg,
      completo: true,
    },
  });

  for (const p of params) {
    const raw = formData.get(`p_${p.id}`);
    if (raw === null || String(raw).trim() === "") continue;
    const valor = parseFloat(String(raw));
    if (isNaN(valor)) continue;

    const hist = p.lecturas.map((l) => l.valor).reverse();
    const status = p.esObservacion
      ? "na"
      : statusOf(valor, p.specMin, p.specMax, p.esMaximo, hist);
    const estado =
      status === "cr" ? "fuera_spec" : status === "wa" ? "deriva" : status === "na" ? "na" : "en_spec";

    const lectura = await prisma.lectura.create({
      data: {
        parametroId: p.id,
        turnoId: turno.id,
        valor,
        estado,
        capturadoPor: session.name,
      },
    });

    // Lectura fuera de rango = EVENTO DE CAUSA para cada causa que este parámetro vigila
    if (estado === "fuera_spec") {
      for (const c of p.causas) {
        await prisma.eventoDeCausa.create({
          data: { causaId: c.id, turnoId: turno.id, lecturaId: lectura.id, detectadoPorControl: true },
        });
      }
    }
  }

  revalidatePath("/");
  revalidatePath("/amef");
  redirect("/?capturado=1");
}

/** Registrar una acción tomada sobre una causa (lo que en producción llega por nota de voz). */
export async function registrarAccion(causaId: string, formData: FormData) {
  const session = await requireSession();
  const descripcion = String(formData.get("descripcion") || "").trim();
  if (!descripcion) return;
  await prisma.accion.create({
    data: {
      causaId,
      descripcion,
      deValor: String(formData.get("deValor") || "").trim() || null,
      aValor: String(formData.get("aValor") || "").trim() || null,
      registradaPor: session.name,
    },
  });
  revalidatePath("/");
  revalidatePath("/amef");
}

/** La pregunta de 48 horas. Un tap, dos opciones. El botón más importante del producto. */
export async function responderEficacia(accionId: string, funciono: boolean) {
  const session = await requireSession();
  await prisma.accion.update({
    where: { id: accionId },
    data: {
      eficacia: funciono ? "funciono" : "no_funciono",
      verificadaPor: session.name,
      verificadaEn: new Date(),
    },
  });
  revalidatePath("/");
  revalidatePath("/amef");
}

/** Aprobar y firmar una propuesta de revisión. El sistema NUNCA aplica cambios solo. */
export async function aprobarPropuesta(propuestaId: string) {
  const session = await requireSession();
  const prop = await prisma.propuestaRevision.findUnique({
    where: { id: propuestaId },
    include: { causa: { include: { modo: true } } },
  });
  if (!prop || prop.estado !== "pendiente") return;

  const numeroRevision =
    (await prisma.revisionAmef.count({ where: { modoId: prop.causa.modoId } })) + 1;

  await prisma.$transaction([
    prisma.propuestaRevision.update({ where: { id: prop.id }, data: { estado: "aprobada" } }),
    prisma.causa.update({
      where: { id: prop.causaId },
      data: prop.tipoRating === "O" ? { ocurrencia: prop.valorPropuesto } : { deteccion: prop.valorPropuesto },
    }),
    prisma.revisionAmef.create({
      data: {
        modoId: prop.causa.modoId,
        causaId: prop.causaId,
        propuestaId: prop.id,
        tipoRating: prop.tipoRating,
        deValor: prop.valorActual,
        aValor: prop.valorPropuesto,
        evidenciaResumen: prop.evidencia.join(" · "),
        aprobadaPor: `${session.name} · Calidad`,
        numeroRevision,
      },
    }),
  ]);

  revalidatePath("/");
  revalidatePath("/amef");
}

/** El rechazo también es evidencia (cláusula 6.1): queda firmado, sin cambio. */
export async function rechazarPropuesta(propuestaId: string) {
  const session = await requireSession();
  const prop = await prisma.propuestaRevision.findUnique({
    where: { id: propuestaId },
    include: { causa: true },
  });
  if (!prop || prop.estado !== "pendiente") return;

  const numeroRevision =
    (await prisma.revisionAmef.count({ where: { modoId: prop.causa.modoId } })) + 1;

  await prisma.$transaction([
    prisma.propuestaRevision.update({ where: { id: prop.id }, data: { estado: "rechazada" } }),
    prisma.revisionAmef.create({
      data: {
        modoId: prop.causa.modoId,
        causaId: prop.causaId,
        propuestaId: prop.id,
        sinCambio: true,
        evidenciaResumen: "Propuesta revisada; se conserva la ocurrencia vigente",
        aprobadaPor: session.name,
        numeroRevision,
      },
    }),
  ]);

  revalidatePath("/");
  revalidatePath("/amef");
}
