// Algoritmos del AMEF vivo — sección 8 del documento de traspaso.

export type ParamStatus = "ok" | "wa" | "cr" | "na";

/**
 * Prioridad de Acción — APROXIMACIÓN.
 * En producción debe sustituirse por la tabla completa del manual AIAG-VDA.
 * La interfaz lo declara siempre en el pie de página.
 */
export function apOf(S: number, O: number, D: number): "A" | "M" | "B" {
  if (S >= 9) return O >= 3 || D >= 5 ? "A" : "M";
  if (S >= 7) return O >= 5 || (O >= 3 && D >= 5) ? "A" : O >= 2 || D >= 5 ? "M" : "B";
  if (S >= 5) return O >= 6 ? "A" : O >= 3 || D >= 6 ? "M" : "B";
  return O >= 7 && D >= 7 ? "M" : "B";
}

/**
 * Estado de un parámetro con detección de deriva.
 * hist = valores de los últimos turnos, en orden cronológico (el último es el más reciente).
 * Deriva = dentro del 18% del extremo de la banda Y tendencia hacia ese extremo.
 */
export function statusOf(
  valor: number | null,
  specMin: number | null,
  specMax: number | null,
  esMaximo: boolean,
  hist: number[]
): ParamStatus {
  if (valor === null || isNaN(valor)) return "na";
  const lo = esMaximo ? null : specMin;
  const hi = specMax;
  if (lo === null && hi === null) return "na";

  if ((lo !== null && valor < lo) || (hi !== null && valor > hi)) return "cr";

  const effLo = lo ?? 0;
  const effHi = hi ?? Infinity;
  if (hi !== null && isFinite(effHi)) {
    const span = effHi - effLo;
    const edge = span * 0.18;
    if (hist.length >= 2) {
      const rising = hist[hist.length - 1] > hist[0];
      const falling = hist[hist.length - 1] < hist[0];
      if (valor > effHi - edge && rising) return "wa";
      if (lo !== null && valor < effLo + edge && falling) return "wa";
    }
  }
  return "ok";
}

export type ModeState = "gap" | "hit" | "drift" | "ok";

export function modeState(paramStatuses: ParamStatus[]): ModeState {
  if (!paramStatuses.length) return "gap"; // sin control en el registro
  if (paramStatuses.some((s) => s === "cr")) return "hit"; // comprometido AHORA
  if (paramStatuses.some((s) => s === "wa")) return "drift";
  return "ok";
}

/** Mapa de tasa observada (eventos/turnos) a nivel de Ocurrencia — ancla práctica, sección 3.2.
 *  ⚠️ Calibrar con el equipo técnico de Trevigo antes de usar frente a cliente. */
export function ocurrenciaDeTasa(eventos: number, turnos: number): number {
  if (turnos <= 0) return 1;
  if (eventos === 0) return turnos > 1000 ? 1 : 2;
  const cada = turnos / eventos; // 1 de cada N turnos
  if (cada <= 1) return 10;
  if (cada <= 2) return 9;
  if (cada <= 5) return 8;
  if (cada <= 10) return 7;
  if (cada <= 20) return 6;
  if (cada <= 50) return 5;
  if (cada <= 100) return 4;
  if (cada <= 200) return 3;
  if (cada <= 500) return 2;
  return 1;
}

export const AP_LABEL: Record<string, string> = { A: "Alta", M: "Media", B: "Baja" };
export const AP_CLASS: Record<string, string> = {
  A: "bg-red-100 text-red-800 border-red-200",
  M: "bg-amber-100 text-amber-800 border-amber-200",
  B: "bg-emerald-100 text-emerald-800 border-emerald-200",
};

export const ESTADO_LABEL: Record<string, string> = {
  ok: "Protegido",
  drift: "En deriva",
  hit: "Comprometido ahora",
  gap: "Sin control en el registro",
};

export const CAT_4M: Record<string, string> = {
  maquina: "Máquina",
  material: "Material",
  metodo: "Método",
  mano_de_obra: "Mano de obra",
  medio_ambiente: "Medio ambiente",
};

export function fmtFecha(d: Date) {
  return d.toLocaleDateString("es-MX", { day: "numeric", month: "short", year: "numeric" });
}

export function fmtFechaHora(d: Date) {
  return d.toLocaleString("es-MX", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

export const PIE_GOBERNANZA =
  "El sistema no modifica el AMEF. Propone con la evidencia; la revisión la aprueba y la firma una persona — el AMEF es documento controlado y el auditor necesita un nombre. Estructura AIAG-VDA; la Prioridad de Acción de esta versión es una aproximación — en producción se usa la tabla completa del manual.";
