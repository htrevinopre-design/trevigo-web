import Link from "next/link";
import type { Session } from "@/lib/auth";

export default function Shell({ session, children }: { session: Session; children: React.ReactNode }) {
  return (
    <div className="min-h-screen">
      <header className="bg-navy-950 text-white">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-5">
            <Link href="/" className="flex items-center gap-3">
              <span className="bg-white rounded-lg px-2 py-1 flex items-center">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="https://www.trevigo.com.mx/logo.png"
                  alt="Industrias Trevigo"
                  className="h-8 w-auto object-contain"
                />
              </span>
              <span className="font-black text-lg tracking-tight hidden sm:inline">
                Trevigo <span className="text-blue-400">CRM</span>
              </span>
            </Link>
            <nav className="flex gap-4 text-sm">
              <Link href="/" className="text-slate-300 hover:text-white font-semibold">CRM</Link>
              <Link href="/registro" className="text-slate-300 hover:text-white font-semibold">Registro</Link>
              <Link href="/leads/new" className="text-slate-300 hover:text-white">+ Nuevo lead</Link>
            </nav>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <span className="text-slate-400 hidden sm:inline">{session.name}</span>
            <form action="/api/auth/logout" method="post">
              <button className="text-slate-300 hover:text-white border border-slate-600 rounded px-3 py-1">
                Salir
              </button>
            </form>
          </div>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 py-6">{children}</main>
    </div>
  );
}
