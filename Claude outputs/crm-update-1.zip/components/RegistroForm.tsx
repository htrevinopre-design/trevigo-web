"use client";

import { useState } from "react";

type LeadOpt = { id: string; name: string; company: string | null; stage: string };

export default function RegistroForm({
  leads,
  action,
}: {
  leads: LeadOpt[];
  action: (formData: FormData) => Promise<void>;
}) {
  const [leadId, setLeadId] = useState(leads.length ? "" : "nuevo");
  const esNuevo = leadId === "nuevo";

  return (
    <form action={action} className="space-y-4 bg-white border border-slate-200 rounded-xl p-6">
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-1">¿De quién fue la llamada?</label>
        <select
          name="leadId"
          value={leadId}
          onChange={(e) => setLeadId(e.target.value)}
          required
          className="w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"
        >
          <option value="" disabled>
            Selecciona un cliente...
          </option>
          <option value="nuevo">➕ Cliente nuevo / no está en la lista</option>
          {leads.map((l) => (
            <option key={l.id} value={l.id}>
              {l.name}
              {l.company ? ` · ${l.company}` : ""}
            </option>
          ))}
        </select>
      </div>

      {esNuevo && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 border-t border-slate-100 pt-4">
          <div className="sm:col-span-2">
            <label className="block text-sm font-semibold text-slate-700 mb-1">Nombre del contacto *</label>
            <input name="name" required={esNuevo} className="w-full border border-slate-300 rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Empresa</label>
            <input name="company" className="w-full border border-slate-300 rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Teléfono</label>
            <input name="phone" className="w-full border border-slate-300 rounded-lg px-3 py-2" />
          </div>
        </div>
      )}

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-1">¿Quién llamó a quién?</label>
        <select name="direction" className="w-full border border-slate-300 rounded-lg px-3 py-2 bg-white">
          <option value="ENTRANTE">Nos llamó el cliente</option>
          <option value="SALIENTE">Nosotros le llamamos</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-1">¿Qué se habló? *</label>
        <textarea
          name="notas"
          rows={4}
          required
          placeholder="Ej. Pidió cotización de 2 tambos de desengrasante. Quedamos de mandarla mañana."
          className="w-full border border-slate-300 rounded-lg px-3 py-2"
        />
      </div>

      <button className="w-full bg-navy-800 hover:bg-navy-900 text-white font-bold py-2.5 rounded-lg">
        Registrar llamada
      </button>
    </form>
  );
}
