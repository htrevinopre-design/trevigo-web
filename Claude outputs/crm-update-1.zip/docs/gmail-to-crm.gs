/**
 * Gmail → Trevigo CRM
 * Corre dentro del Gmail de la empresa (script.google.com) cada 5 minutos.
 * Toma los correos nuevos de la bandeja, los manda al CRM y les pone la
 * etiqueta "CRM" para no procesarlos dos veces. Gratis, sin servidor.
 *
 * INSTALACIÓN (te guío en el chat):
 * 1. Entrar a script.google.com CON LA CUENTA DE GMAIL donde llegan los
 *    requerimientos de clientes → Nuevo proyecto.
 * 2. Pegar este archivo completo. Llenar CRM_URL e INTAKE_SECRET abajo.
 * 3. Ejecutar una vez la función "instalar" (pide permisos de Gmail: aceptar).
 * 4. Listo: revisa la bandeja cada 5 minutos.
 */

// ⚠️ LLENAR ESTOS DOS VALORES:
var CRM_URL = "https://admin.trevigo.com.mx/api/email-intake";
var INTAKE_SECRET = "PEGA_AQUI_EL_INTAKE_SECRET_DE_TU_ENV";

// Correos internos que NO se registran como leads (agregar los del equipo):
var IGNORAR = ["@trevigo.com.mx", "no-reply", "noreply", "mailer-daemon", "notifications"];

function instalar() {
  // etiqueta de control
  if (!GmailApp.getUserLabelByName("CRM")) GmailApp.createLabel("CRM");
  // borra triggers previos de este proyecto y crea el de cada 5 min
  ScriptApp.getProjectTriggers().forEach(function (t) { ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger("procesarCorreos").timeBased().everyMinutes(5).create();
  procesarCorreos();
}

function procesarCorreos() {
  var label = GmailApp.getUserLabelByName("CRM");
  // hilos de la bandeja de los últimos 2 días que aún no tienen la etiqueta CRM
  var hilos = GmailApp.search("in:inbox newer_than:2d -label:CRM");
  for (var i = 0; i < hilos.length; i++) {
    var hilo = hilos[i];
    var msgs = hilo.getMessages();
    var m = msgs[msgs.length - 1]; // el mensaje más reciente del hilo
    var de = m.getFrom(); // "Nombre <correo@dominio.com>"

    var correo = (de.match(/<(.+)>/) || [null, de])[1].toLowerCase().trim();
    var nombre = de.replace(/<.+>/, "").replace(/"/g, "").trim() || correo;

    var ignorar = IGNORAR.some(function (x) { return correo.indexOf(x) !== -1; });
    if (!ignorar) {
      var payload = {
        fromEmail: correo,
        fromName: nombre,
        subject: m.getSubject(),
        body: m.getPlainBody().substring(0, 6000),
      };
      try {
        UrlFetchApp.fetch(CRM_URL, {
          method: "post",
          contentType: "application/json",
          headers: { "x-intake-secret": INTAKE_SECRET },
          payload: JSON.stringify(payload),
          muteHttpExceptions: true,
        });
      } catch (e) {
        // si el CRM no responde, no marcamos el hilo: se reintenta en 5 min
        continue;
      }
    }
    hilo.addLabel(label);
  }
}
