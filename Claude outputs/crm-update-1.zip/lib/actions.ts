"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { Channel, Direction, QuoteStatus, Stage } from "@prisma/client";

async function requireSession() {
  const session = await getSession();
  if (!session) redirect("/login");
  return session;
}

export async function createLead(formData: FormData) {
  await requireSession();
  const name = String(formData.get("name") || "").trim();
  if (!name) return;

  const message = String(formData.get("message") || "").trim();
  const channel = String(formData.get("channel") || "OTRO") as Channel;

  const lead = await prisma.lead.create({
    data: {
      name,
      company: String(formData.get("company") || "").trim() || null,
      email: String(formData.get("email") || "").trim() || null,
      phone: String(formData.get("phone") || "").trim() || null,
      channel,
      summary: message.slice(0, 300) || null,
      messages: message
        ? { create: { direction: Direction.ENTRANTE, channel, body: message } }
        : undefined,
    },
  });

  revalidatePath("/");
  redirect(`/leads/${lead.id}`);
}

/** Registro rápido de llamadas: sobre un lead existente o creando uno nuevo. */
export async function registrarLlamada(formData: FormData) {
  const session = await requireSession();
  const leadId = String(formData.get("leadId") || "");
  const notas = String(formData.get("notas") || "").trim();
  const direction = String(formData.get("direction") || "ENTRANTE") as Direction;
  if (!notas) return;

  if (leadId && leadId !== "nuevo") {
    await prisma.$transaction([
      prisma.message.create({
        data: { leadId, direction, channel: Channel.LLAMADA, body: notas, authorId: session.userId },
      }),
      prisma.lead.update({ where: { id: leadId }, data: { lastContactAt: new Date() } }),
    ]);
    revalidatePath("/");
    redirect(`/leads/${leadId}`);
  }

  const name = String(formData.get("name") || "").trim();
  if (!name) return;
  const lead = await prisma.lead.create({
    data: {
      name,
      company: String(formData.get("company") || "").trim() || null,
      phone: String(formData.get("phone") || "").trim() || null,
      channel: Channel.LLAMADA,
      summary: notas.slice(0, 300),
      messages: { create: { direction, channel: Channel.LLAMADA, body: notas, authorId: session.userId } },
    },
  });
  revalidatePath("/");
  redirect(`/leads/${lead.id}`);
}

export async function updateStage(leadId: string, formData: FormData) {
  await requireSession();
  const stage = String(formData.get("stage")) as Stage;
  await prisma.lead.update({
    where: { id: leadId },
    data: { stage, lastContactAt: new Date() },
  });
  revalidatePath("/");
  revalidatePath(`/leads/${leadId}`);
}

export async function addMessage(leadId: string, formData: FormData) {
  const session = await requireSession();
  const body = String(formData.get("body") || "").trim();
  if (!body) return;
  const direction = String(formData.get("direction") || "NOTA") as Direction;
  const channel = String(formData.get("channel") || "OTRO") as Channel;

  await prisma.$transaction([
    prisma.message.create({
      data: { leadId, direction, channel, body, authorId: session.userId },
    }),
    prisma.lead.update({ where: { id: leadId }, data: { lastContactAt: new Date() } }),
  ]);

  revalidatePath(`/leads/${leadId}`);
  revalidatePath("/");
}

export async function addQuote(leadId: string, formData: FormData) {
  await requireSession();
  const concept = String(formData.get("concept") || "").trim();
  const amount = parseFloat(String(formData.get("amountMxn") || "0"));
  if (!concept || !amount || isNaN(amount)) return;

  await prisma.$transaction([
    prisma.quote.create({ data: { leadId, concept, amountMxn: amount } }),
    prisma.lead.update({
      where: { id: leadId },
      data: { stage: Stage.COTIZADO, lastContactAt: new Date() },
    }),
  ]);

  revalidatePath(`/leads/${leadId}`);
  revalidatePath("/");
}

export async function updateQuoteStatus(quoteId: string, leadId: string, formData: FormData) {
  await requireSession();
  const status = String(formData.get("status")) as QuoteStatus;
  await prisma.quote.update({ where: { id: quoteId }, data: { status } });
  revalidatePath(`/leads/${leadId}`);
}

export async function closeLead(leadId: string, formData: FormData) {
  await requireSession();
  const won = String(formData.get("outcome")) === "GANADO";
  const amount = parseFloat(String(formData.get("closedAmount") || "0"));

  await prisma.lead.update({
    where: { id: leadId },
    data: {
      stage: won ? Stage.GANADO : Stage.PERDIDO,
      closedAmount: won && amount && !isNaN(amount) ? amount : null,
      lastContactAt: new Date(),
    },
  });

  revalidatePath("/");
  revalidatePath(`/leads/${leadId}`);
}
