import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getSession } from "@/lib/auth";
import Shell from "@/components/Shell";
import { registrarLlamada } from "@/lib/actions";
import RegistroForm from "@/components/RegistroForm";

export const dynamic = "force-dynamic";

export default async function RegistroPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  const leads = await prisma.lead.findMany({
    orderBy: { lastContactAt: "desc" },
    take: 100,
    select: { id: true, name: true, company: true, stage: true },
  });

  return (
    <Shell session={session}>
      <div className="max-w-lg mx-auto">
        <h1 className="text-xl font-black text-navy-950 mb-1">Registrar llamada</h1>
        <p className="text-sm text-slate-500 mb-5">
          Colgaste el teléfono, escribes tres líneas, y la llamada queda en el historial del cliente. 30 segundos.
        </p>
        <RegistroForm action={registrarLlamada} leads={leads} />
      </div>
    </Shell>
  );
}
