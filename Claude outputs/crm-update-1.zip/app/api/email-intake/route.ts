import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * Puerta de entrada de CORREO. La usa el script de Gmail (Apps Script):
 * POST con header "x-intake-secret" = INTAKE_SECRET y JSON
 * { fromEmail, fromName?, subject?, body }.
 * Si existe un lead abierto con ese correo, agrega el mensaje a su historial;
 * si no, crea el lead con canal CORREO.
 */
export async function POST(req: NextRequest) {
  const secret = req.headers.get("x-intake-secret");
  if (!process.env.INTAKE_SECRET || secret !== process.env.INTAKE_SECRET) {
    return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  }

  const data = await req.json().catch(() => null);
  if (!data || !data.fromEmail || !data.body) {
    return NextResponse.json({ error: "Faltan campos (fromEmail, body)" }, { status: 400 });
  }

  const fromEmail = String(data.fromEmail).toLowerCase().trim().slice(0, 200);
  const subject = data.subject ? String(data.subject).slice(0, 200) : null;
  const body = String(data.body).slice(0, 8000);
  const texto = subject ? `Asunto: ${subject}\n\n${body}` : body;

  const existente = await prisma.lead.findFirst({
    where: { email: fromEmail, stage: { in: ["NUEVO", "COTIZADO", "SEGUIMIENTO"] } },
    orderBy: { lastContactAt: "desc" },
  });

  if (existente) {
    await prisma.$transaction([
      prisma.message.create({
        data: { leadId: existente.id, direction: "ENTRANTE", channel: "CORREO", body: texto },
      }),
      prisma.lead.update({ where: { id: existente.id }, data: { lastContactAt: new Date() } }),
    ]);
    return NextResponse.json({ ok: true, leadId: existente.id, existente: true });
  }

  const lead = await prisma.lead.create({
    data: {
      name: data.fromName ? String(data.fromName).slice(0, 200) : fromEmail,
      email: fromEmail,
      channel: "CORREO",
      summary: (subject || body).slice(0, 300),
      messages: { create: { direction: "ENTRANTE", channel: "CORREO", body: texto } },
    },
  });
  return NextResponse.json({ ok: true, leadId: lead.id, existente: false });
}
