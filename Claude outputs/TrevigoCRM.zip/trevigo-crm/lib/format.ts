export function fmtMxn(n: number | string | null | undefined) {
  if (n === null || n === undefined) return "—";
  const num = typeof n === "string" ? parseFloat(n) : n;
  return num.toLocaleString("es-MX", { style: "currency", currency: "MXN", maximumFractionDigits: 0 });
}

export function fmtDate(d: Date) {
  return d.toLocaleDateString("es-MX", { day: "numeric", month: "short", year: "numeric" });
}

export function fmtDateTime(d: Date) {
  return d.toLocaleString("es-MX", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

export function daysSince(d: Date) {
  return Math.floor((Date.now() - d.getTime()) / 86400000);
}

export const STAGE_LABELS: Record<string, string> = {
  NUEVO: "Nuevo",
  COTIZADO: "Cotizado",
  SEGUIMIENTO: "En seguimiento",
  GANADO: "Ganado",
  PERDIDO: "Perdido",
};

export const CHANNEL_LABELS: Record<string, string> = {
  WHATSAPP: "WhatsApp",
  CORREO: "Correo",
  FORMULARIO: "Formulario web",
  LLAMADA: "Llamada",
  OTRO: "Otro",
};

export const CHANNEL_ICONS: Record<string, string> = {
  WHATSAPP: "💬",
  CORREO: "✉️",
  FORMULARIO: "🌐",
  LLAMADA: "📞",
  OTRO: "📎",
};
