import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: {
          50: "#f0f4f9",
          600: "#1e3a5f",
          800: "#122a47",
          900: "#0c1f36",
          950: "#081527",
        },
      },
    },
  },
  plugins: [],
};
export default config;
