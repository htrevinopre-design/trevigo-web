import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const INITIAL_PASSWORD = process.env.SEED_PASSWORD || "trevigo2026";

const USERS = [
  { email: "hernan@trevigo.com.mx", name: "Hernán", role: "ADMIN" },
  { email: "blanca@trevigo.com.mx", name: "Blanca", role: "USUARIO" },
  { email: "norma@trevigo.com.mx", name: "Norma", role: "USUARIO" },
];

async function main() {
  const passwordHash = await bcrypt.hash(INITIAL_PASSWORD, 10);
  for (const u of USERS) {
    await prisma.user.upsert({
      where: { email: u.email },
      update: {},
      create: { ...u, passwordHash },
    });
  }
  console.log("Usuarios creados. Contraseña inicial:", INITIAL_PASSWORD);
  console.log("IMPORTANTE: cámbienla después de entrar por primera vez.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
