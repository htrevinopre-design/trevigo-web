# Trevigo CRM

CRM interno de Industrias Trevigo. Registra leads de WhatsApp, correo, formulario web y llamadas; pipeline de cotizaciones; seguimiento automático de leads olvidados.

## Puesta en marcha (una sola vez)

### 1. Base de datos (Neon, gratis)
1. Crear cuenta en https://neon.tech (con el correo de Google es un clic).
2. Crear un proyecto llamado `trevigo-crm` (región: US East).
3. Copiar la **connection string** que te muestra (empieza con `postgresql://`).

### 2. Subir el código a GitHub
```bash
cd ~/Desktop/TrevigoCRM
git init
git add .
git commit -m "CRM v1"
# crear repo vacío "trevigo-crm" (privado) en github.com, luego:
git remote add origin https://github.com/TU_USUARIO/trevigo-crm.git
git push -u origin main
```

### 3. Vercel
1. En vercel.com → Add New → Project → importar `trevigo-crm`.
2. En **Environment Variables** agregar (ver `.env.example`):
   - `DATABASE_URL` = la connection string de Neon
   - `AUTH_SECRET` = texto largo aleatorio
   - `INTAKE_SECRET` = otro texto aleatorio
3. Deploy.

### 4. Crear tablas y usuarios (desde tu Mac)
```bash
cd ~/Desktop/TrevigoCRM
cp .env.example .env   # y llenar con los mismos valores de Vercel
npm install
npm run db:push        # crea las tablas en Neon
npm run db:seed        # crea usuarios: hernan@, blanca@, norma@trevigo.com.mx
```
Contraseña inicial: la de `SEED_PASSWORD` (cambiar después).

### 5. Subdominio
En el DNS de trevigo.com.mx agregar un registro CNAME:
`crm` → `cname.vercel-dns.com`
y en Vercel → Settings → Domains agregar `crm.trevigo.com.mx`.

## Conectar el formulario del sitio
El sitio (TrevigoWeb) debe hacer POST a `https://crm.trevigo.com.mx/api/intake` con header `x-intake-secret: INTAKE_SECRET` y JSON `{ name, email, phone, company, message }`. (Este cambio lo hacemos en el repo del sitio.)

## Desarrollo local
```bash
npm install
npm run dev   # http://localhost:3000
```
