import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getSession } from "@/lib/auth";
import Shell from "@/components/Shell";
import { fmtMxn, fmtDate, daysSince, STAGE_LABELS, CHANNEL_ICONS } from "@/lib/format";

export const dynamic = "force-dynamic";

const PIPELINE: Array<"NUEVO" | "COTIZADO" | "SEGUIMIENTO"> = ["NUEVO", "COTIZADO", "SEGUIMIENTO"];

export default async function Dashboard() {
  const session = await getSession();
  if (!session) redirect("/login");

  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const [active, wonThisMonth, closed] = await Promise.all([
    prisma.lead.findMany({
      where: { stage: { in: PIPELINE } },
      orderBy: { lastContactAt: "asc" },
      include: { quotes: { orderBy: { sentAt: "desc" }, take: 1 } },
    }),
    prisma.lead.aggregate({
      where: { stage: "GANADO", updatedAt: { gte: monthStart } },
      _sum: { closedAmount: true },
      _count: true,
    }),
    prisma.lead.findMany({
      where: { stage: { in: ["GANADO", "PERDIDO"] } },
      orderBy: { updatedAt: "desc" },
      take: 8,
    }),
  ]);

  const overdue = active.filter(
    (l) => (l.stage === "COTIZADO" || l.stage === "SEGUIMIENTO") && daysSince(l.lastContactAt) >= 3
  );

  return (
    <Shell session={session}>
      {/* Resumen */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <Stat label="Leads activos" value={String(active.length)} />
        <Stat
          label="Requieren seguimiento"
          value={String(overdue.length)}
          alert={overdue.length > 0}
        />
        <Stat label="Ganados este mes" value={String(wonThisMonth._count)} />
        <Stat label="Cerrado este mes" value={fmtMxn(wonThisMonth._sum.closedAmount?.toString() ?? 0)} />
      </div>

      {/* Seguimientos vencidos */}
      {overdue.length > 0 && (
        <div className="bg-amber-50 border border-amber-300 rounded-xl p-4 mb-6">
          <p className="font-bold text-amber-800 mb-2">
            ⚠ {overdue.length === 1 ? "1 lead lleva" : `${overdue.length} leads llevan`} 3+ días sin contacto
          </p>
          <ul className="space-y-1">
            {overdue.map((l) => (
              <li key={l.id}>
                <Link href={`/leads/${l.id}`} className="text-sm text-amber-900 hover:underline">
                  {CHANNEL_ICONS[l.channel]} <strong>{l.name}</strong>
                  {l.company ? ` · ${l.company}` : ""} — {daysSince(l.lastContactAt)} días sin contacto (
                  {STAGE_LABELS[l.stage]})
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Pipeline */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {PIPELINE.map((stage) => {
          const leads = active.filter((l) => l.stage === stage);
          return (
            <div key={stage} className="bg-white rounded-xl border border-slate-200 p-4">
              <h2 className="font-black text-navy-950 text-sm uppercase tracking-wide mb-3">
                {STAGE_LABELS[stage]} <span className="text-slate-400 font-normal">({leads.length})</span>
              </h2>
              <div className="space-y-2">
                {leads.length === 0 && <p className="text-slate-400 text-sm">Sin leads aquí</p>}
                {leads.map((l) => (
                  <Link
                    key={l.id}
                    href={`/leads/${l.id}`}
                    className="block border border-slate-200 rounded-lg p-3 hover:border-navy-600 hover:shadow-sm transition-all"
                  >
                    <p className="font-semibold text-sm text-navy-950">
                      {CHANNEL_ICONS[l.channel]} {l.name}
                    </p>
                    {l.company && <p className="text-xs text-slate-500">{l.company}</p>}
                    {l.summary && <p className="text-xs text-slate-500 mt-1 line-clamp-2">{l.summary}</p>}
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-[11px] text-slate-400">{fmtDate(l.createdAt)}</span>
                      {l.quotes[0] && (
                        <span className="text-[11px] font-bold text-emerald-700">
                          {fmtMxn(l.quotes[0].amountMxn.toString())}
                        </span>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Cerrados recientes */}
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <h2 className="font-black text-navy-950 text-sm uppercase tracking-wide mb-3">Cerrados recientes</h2>
        {closed.length === 0 && <p className="text-slate-400 text-sm">Todavía no hay leads cerrados</p>}
        <ul className="divide-y divide-slate-100">
          {closed.map((l) => (
            <li key={l.id} className="py-2 flex items-center justify-between">
              <Link href={`/leads/${l.id}`} className="text-sm hover:underline">
                {l.name}
                {l.company ? ` · ${l.company}` : ""}
              </Link>
              <span
                className={`text-xs font-bold ${l.stage === "GANADO" ? "text-emerald-700" : "text-slate-400"}`}
              >
                {l.stage === "GANADO" ? `Ganado ${fmtMxn(l.closedAmount?.toString())}` : "Perdido"}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </Shell>
  );
}

function Stat({ label, value, alert }: { label: string; value: string; alert?: boolean }) {
  return (
    <div className={`rounded-xl border p-4 ${alert ? "bg-amber-50 border-amber-300" : "bg-white border-slate-200"}`}>
      <p className="text-[11px] uppercase tracking-wide font-bold text-slate-400">{label}</p>
      <p className={`text-2xl font-black ${alert ? "text-amber-700" : "text-navy-950"}`}>{value}</p>
    </div>
  );
}
