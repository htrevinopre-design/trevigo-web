import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * Endpoint público para el formulario de trevigo.com.mx.
 * El sitio manda POST con header "x-intake-secret" = INTAKE_SECRET.
 * Crea el lead y guarda el mensaje original en el timeline.
 */
export async function POST(req: NextRequest) {
  const secret = req.headers.get("x-intake-secret");
  if (!process.env.INTAKE_SECRET || secret !== process.env.INTAKE_SECRET) {
    return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  if (!body || !body.name || !body.message) {
    return NextResponse.json({ error: "Faltan campos (name, message)" }, { status: 400 });
  }

  const lead = await prisma.lead.create({
    data: {
      name: String(body.name).slice(0, 200),
      company: body.company ? String(body.company).slice(0, 200) : null,
      email: body.email ? String(body.email).slice(0, 200) : null,
      phone: body.phone ? String(body.phone).slice(0, 50) : null,
      channel: "FORMULARIO",
      summary: String(body.message).slice(0, 300),
      messages: {
        create: {
          direction: "ENTRANTE",
          channel: "FORMULARIO",
          body: String(body.message).slice(0, 5000),
        },
      },
    },
  });

  return NextResponse.json({ ok: true, leadId: lead.id });
}
