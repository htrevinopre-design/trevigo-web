import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { createLead } from "@/lib/actions";
import Shell from "@/components/Shell";

export const dynamic = "force-dynamic";

export default async function NewLeadPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  return (
    <Shell session={session}>
      <div className="max-w-lg mx-auto bg-white rounded-xl border border-slate-200 p-6">
        <h1 className="text-xl font-black text-navy-950 mb-4">Registrar lead</h1>
        <form action={createLead} className="space-y-4">
          <Field name="name" label="Nombre del contacto *" required />
          <Field name="company" label="Empresa" />
          <div className="grid grid-cols-2 gap-3">
            <Field name="email" label="Correo" type="email" />
            <Field name="phone" label="Teléfono / WhatsApp" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">¿Por dónde llegó?</label>
            <select
              name="channel"
              className="w-full border border-slate-300 rounded-lg px-3 py-2 bg-white"
              defaultValue="WHATSAPP"
            >
              <option value="WHATSAPP">WhatsApp</option>
              <option value="CORREO">Correo</option>
              <option value="LLAMADA">Llamada</option>
              <option value="FORMULARIO">Formulario web</option>
              <option value="OTRO">Otro</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">¿Qué pidió?</label>
            <textarea
              name="message"
              rows={4}
              className="w-full border border-slate-300 rounded-lg px-3 py-2"
              placeholder="Ej. Cotización de 2 tambos de desengrasante alcalino para planta en Apodaca"
            />
          </div>
          <button className="w-full bg-navy-800 hover:bg-navy-900 text-white font-bold py-2.5 rounded-lg">
            Guardar lead
          </button>
        </form>
      </div>
    </Shell>
  );
}

function Field({
  name,
  label,
  type = "text",
  required,
}: {
  name: string;
  label: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="block text-sm font-semibold text-slate-700 mb-1">{label}</label>
      <input
        name={name}
        type={type}
        required={required}
        className="w-full border border-slate-300 rounded-lg px-3 py-2"
      />
    </div>
  );
}
