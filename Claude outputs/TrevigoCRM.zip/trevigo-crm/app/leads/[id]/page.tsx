import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getSession } from "@/lib/auth";
import Shell from "@/components/Shell";
import { addMessage, addQuote, closeLead, updateQuoteStatus, updateStage } from "@/lib/actions";
import {
  fmtMxn,
  fmtDateTime,
  daysSince,
  STAGE_LABELS,
  CHANNEL_LABELS,
  CHANNEL_ICONS,
} from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function LeadPage({ params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) redirect("/login");

  const lead = await prisma.lead.findUnique({
    where: { id: params.id },
    include: {
      messages: { orderBy: { createdAt: "asc" }, include: { author: true } },
      quotes: { orderBy: { sentAt: "desc" } },
    },
  });
  if (!lead) notFound();

  const isOpen = lead.stage !== "GANADO" && lead.stage !== "PERDIDO";
  const stale = isOpen && daysSince(lead.lastContactAt) >= 3;

  return (
    <Shell session={session}>
      <Link href="/" className="text-sm text-slate-500 hover:text-navy-950">← Tablero</Link>

      <div className="grid grid-cols-1 lg:grid-cols-[1.5fr_1fr] gap-6 mt-3">
        {/* Columna principal */}
        <div className="space-y-6">
          {/* Header */}
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h1 className="text-2xl font-black text-navy-950">
                  {CHANNEL_ICONS[lead.channel]} {lead.name}
                </h1>
                {lead.company && <p className="text-slate-500">{lead.company}</p>}
                <p className="text-sm text-slate-400 mt-1">
                  {CHANNEL_LABELS[lead.channel]}
                  {lead.email ? ` · ${lead.email}` : ""}
                  {lead.phone ? ` · ${lead.phone}` : ""}
                </p>
              </div>
              <div className="text-right">
                <span
                  className={`inline-block text-xs font-black uppercase tracking-wide rounded-full px-3 py-1 ${
                    lead.stage === "GANADO"
                      ? "bg-emerald-100 text-emerald-800"
                      : lead.stage === "PERDIDO"
                        ? "bg-slate-200 text-slate-600"
                        : "bg-blue-100 text-blue-800"
                  }`}
                >
                  {STAGE_LABELS[lead.stage]}
                </span>
                {stale && (
                  <p className="text-xs text-amber-700 font-bold mt-2">
                    ⚠ {daysSince(lead.lastContactAt)} días sin contacto
                  </p>
                )}
              </div>
            </div>

            {isOpen && (
              <form action={updateStage.bind(null, lead.id)} className="flex gap-2 mt-4">
                <select
                  name="stage"
                  defaultValue={lead.stage}
                  className="border border-slate-300 rounded-lg px-3 py-1.5 text-sm bg-white"
                >
                  <option value="NUEVO">Nuevo</option>
                  <option value="COTIZADO">Cotizado</option>
                  <option value="SEGUIMIENTO">En seguimiento</option>
                </select>
                <button className="bg-slate-800 hover:bg-navy-950 text-white text-sm font-bold px-4 py-1.5 rounded-lg">
                  Cambiar etapa
                </button>
              </form>
            )}
          </div>

          {/* Timeline */}
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h2 className="font-black text-navy-950 text-sm uppercase tracking-wide mb-4">Conversación y notas</h2>
            <div className="space-y-3 mb-5">
              {lead.messages.length === 0 && (
                <p className="text-slate-400 text-sm">Sin mensajes registrados</p>
              )}
              {lead.messages.map((m) => (
                <div
                  key={m.id}
                  className={`rounded-lg p-3 text-sm ${
                    m.direction === "ENTRANTE"
                      ? "bg-slate-100"
                      : m.direction === "SALIENTE"
                        ? "bg-blue-50 border border-blue-100"
                        : "bg-amber-50 border border-amber-100"
                  }`}
                >
                  <p className="text-[11px] font-bold text-slate-500 mb-1">
                    {m.direction === "ENTRANTE"
                      ? `Cliente · ${CHANNEL_LABELS[m.channel]}`
                      : m.direction === "SALIENTE"
                        ? `${m.author?.name ?? "Trevigo"} · ${CHANNEL_LABELS[m.channel]}`
                        : `Nota interna · ${m.author?.name ?? ""}`}{" "}
                    · {fmtDateTime(m.createdAt)}
                  </p>
                  <p className="whitespace-pre-wrap">{m.body}</p>
                </div>
              ))}
            </div>

            <form action={addMessage.bind(null, lead.id)} className="space-y-2">
              <textarea
                name="body"
                rows={3}
                required
                placeholder="Registrar mensaje del cliente, respuesta enviada, o nota interna..."
                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
              />
              <div className="flex flex-wrap gap-2">
                <select name="direction" className="border border-slate-300 rounded-lg px-2 py-1.5 text-sm bg-white">
                  <option value="NOTA">Nota interna</option>
                  <option value="ENTRANTE">Mensaje del cliente</option>
                  <option value="SALIENTE">Respuesta enviada</option>
                </select>
                <select
                  name="channel"
                  defaultValue={lead.channel}
                  className="border border-slate-300 rounded-lg px-2 py-1.5 text-sm bg-white"
                >
                  <option value="WHATSAPP">WhatsApp</option>
                  <option value="CORREO">Correo</option>
                  <option value="LLAMADA">Llamada</option>
                  <option value="FORMULARIO">Formulario</option>
                  <option value="OTRO">Otro</option>
                </select>
                <button className="bg-navy-800 hover:bg-navy-950 text-white text-sm font-bold px-4 py-1.5 rounded-lg">
                  Registrar
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Columna lateral */}
        <div className="space-y-6">
          {/* Cotizaciones */}
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h2 className="font-black text-navy-950 text-sm uppercase tracking-wide mb-4">Cotizaciones</h2>
            <div className="space-y-3 mb-4">
              {lead.quotes.length === 0 && <p className="text-slate-400 text-sm">Sin cotizaciones</p>}
              {lead.quotes.map((q) => (
                <div key={q.id} className="border border-slate-200 rounded-lg p-3">
                  <div className="flex justify-between items-start gap-2">
                    <p className="text-sm font-semibold">{q.concept}</p>
                    <p className="text-sm font-black text-navy-950 whitespace-nowrap">
                      {fmtMxn(q.amountMxn.toString())}
                    </p>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">{fmtDateTime(q.sentAt)}</p>
                  <form
                    action={updateQuoteStatus.bind(null, q.id, lead.id)}
                    className="flex gap-2 mt-2"
                  >
                    <select
                      name="status"
                      defaultValue={q.status}
                      className="border border-slate-300 rounded px-2 py-1 text-xs bg-white"
                    >
                      <option value="BORRADOR">Borrador</option>
                      <option value="ENVIADA">Enviada</option>
                      <option value="ACEPTADA">Aceptada</option>
                      <option value="RECHAZADA">Rechazada</option>
                    </select>
                    <button className="text-xs font-bold text-slate-600 border border-slate-300 rounded px-2 py-1 hover:bg-slate-100">
                      Actualizar
                    </button>
                  </form>
                </div>
              ))}
            </div>

            {isOpen && (
              <form action={addQuote.bind(null, lead.id)} className="space-y-2 border-t border-slate-100 pt-4">
                <input
                  name="concept"
                  required
                  placeholder="Concepto (ej. 2 tambos desengrasante)"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
                />
                <input
                  name="amountMxn"
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  placeholder="Monto MXN"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
                />
                <button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold py-2 rounded-lg">
                  + Agregar cotización
                </button>
              </form>
            )}
          </div>

          {/* Cerrar lead */}
          {isOpen && (
            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <h2 className="font-black text-navy-950 text-sm uppercase tracking-wide mb-3">Cerrar lead</h2>
              <form action={closeLead.bind(null, lead.id)} className="space-y-2">
                <select name="outcome" className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm bg-white">
                  <option value="GANADO">Ganado (se cerró la venta)</option>
                  <option value="PERDIDO">Perdido</option>
                </select>
                <input
                  name="closedAmount"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="Monto final MXN (si ganado)"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm"
                />
                <button className="w-full bg-navy-950 hover:bg-navy-900 text-white text-sm font-bold py-2 rounded-lg">
                  Cerrar
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </Shell>
  );
}
